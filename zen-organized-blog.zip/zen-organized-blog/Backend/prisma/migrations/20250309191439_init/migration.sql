-- DropIndex
DROP INDEX "Users_name_key";
