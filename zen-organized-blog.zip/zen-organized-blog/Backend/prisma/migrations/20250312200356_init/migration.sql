-- AlterTable
ALTER TABLE "Save" ADD COLUMN     "isSaved" BOOLEAN NOT NULL DEFAULT false;
