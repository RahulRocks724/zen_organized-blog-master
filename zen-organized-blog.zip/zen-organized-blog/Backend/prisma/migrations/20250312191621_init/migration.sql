-- AlterTable
ALTER TABLE "Likes" ADD COLUMN     "isLiked" BOOLEAN NOT NULL DEFAULT false;
