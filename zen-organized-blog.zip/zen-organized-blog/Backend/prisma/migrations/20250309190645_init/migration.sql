-- AlterTable
ALTER TABLE "Users" ADD COLUMN     "bio" VARCHAR(250);
